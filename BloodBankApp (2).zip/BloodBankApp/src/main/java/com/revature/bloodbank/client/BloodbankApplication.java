package com.revature.bloodbank.client;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.revature.bloodbank.controller.BloodBankController;
import com.revature.bloodbank.exception.InvalidIpException;
import com.revature.bloodbank.model.BloodBankCenter;

public class BloodbankApplication {
	 static  Logger logger=Logger.getLogger(BloodbankApplication.class);

	public static void main(String[] args)  throws InvalidIpException{
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("===========BloodBank Application===========");
		logger.info("Opened BloodBankApplication");
		BloodBankController bcontroller=new BloodBankController();
		BloodBankCenter bloodBankCenter=new  BloodBankCenter();
		int centerId;
		String centerName;
		String street;
		String city;
		String state;
		int pincode;
		int choice = 0;
		do{
			System.out.println("1.add\n2.delete\n3.update\n4.display all blood bank centers\n5.display specific one\n Enter any number to exit ");
			boolean done=false;
			while(!done)
			try{
				System.out.println("********************Enter your choice********************");
				logger.info("Entering the choice");
				choice=sc.nextInt();
				done=true;
			}catch(InputMismatchException e){
				logger.error("Entering invalid choice other than integer");
				String str=sc.nextLine();
				System.out.println("Enter only number");
			}
		switch(choice)
		{
		case 1:System.out.println("******************** Inserting Data ********************");
					System.out.print("Enter id:");
					try{
					centerId=sc.nextInt();sc.nextLine();
					if(centerId<0 )
					{
						throw new InvalidIpException();
					}
					System.out.print("Enter name:");
					centerName=sc.nextLine();;
					System.out.print("Enter street:");
					street=sc.nextLine();;
					System.out.print("Enter city:");
					city=sc.nextLine();;
					System.out.print("Enter state:");
					state=sc.nextLine();;
					System.out.print("Enter pincode:");
					pincode=sc.nextInt();
					bloodBankCenter.setCenterId(centerId);
					bloodBankCenter.setCenterName(centerName);
					bloodBankCenter.setStreet(street);
					bloodBankCenter.setCity(city);
					bloodBankCenter.setState(state);
					bloodBankCenter.setPincode(pincode);
					}catch(InvalidIpException e)
					{
						System.out.println(e);
					}
					logger.info("calling addBloodBankCenter method in controller");
					bcontroller.addBloodBankCenter(bloodBankCenter);
					break;
		case 2:System.out.println("********************deleting specific entry********************");
					System.out.print("Enter id to delete:");
					centerId=sc.nextInt();
					logger.info("calling deleteBloodBankCenter method in controller");
					bcontroller.deleteBloodBankCenter(centerId);
					break;
		case 3:System.out.println("********************Updating specific entry********************");
					System.out.print("Enter id:");
					centerId=sc.nextInt();
					sc.nextLine();
					System.out.print("Enter name to update:");
					centerName=sc.nextLine();
					logger.info("calling updateBloodBankCenter method in controller");
					bcontroller.updateBloodBankCenter(centerId,centerName);
					break;
		case 4:System.out.println("********************displaying all entries********************"); 
					logger.info("calling getAllcenters method in controller");
					System.out.println(bcontroller.getAllcenters());
					
					System.out.println("");
					System.out.println("*****************************************************************");
					break;
		case 5:System.out.println("********************displaying specific entry********************");
					System.out.print("Enter id:");
					centerId=sc.nextInt();
					logger.info("calling getCenterById method in controller");
					System.out.println(bcontroller.getCenterById(centerId));
					logger.info("calling getCenterById method in controller");
					System.out.println("");
					System.out.println("*****************************************************************");
					break;
		default:logger.fatal("choosing other than 1,2,3,4,5");
						System.out.println("********************exit********************");
						System.exit(0);
						break;
		}
		 
		}while(choice>=1&&choice<=5);
		 
		
	}
}
