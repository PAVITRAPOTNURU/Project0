package com.revature.bloodbank.exception;

public class InvalidIpException extends Exception{
	public String toString()
	{
		return"Enter only positive numbers";
	}
}
