package com.revature.bloodbank.controller;

import java.util.List;

import org.apache.log4j.Logger;

import com.revature.bloodbank.model.BloodBankCenter;
import com.revature.bloodbank.service.BloodBankService;
import com.revature.bloodbank.service.BloodBankServiceImpl;

public class BloodBankController {
	static  Logger logger=Logger.getLogger(BloodBankController.class);
	BloodBankService bloodBankServiceImpl=new BloodBankServiceImpl();
	 public  void addBloodBankCenter(BloodBankCenter bloodBankCenter ){
		   logger.info("In controller for adding.....");
		  try {
			bloodBankServiceImpl.addBloodBankCenter(bloodBankCenter);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   }
	 	public void deleteBloodBankCenter(int id) 
	 	{
	 		logger.info("In controller for deleting....");
	 		 try {
	 			bloodBankServiceImpl.deleteBloodBankCenter(id);
	 		} catch (Exception e) {
	 			e.printStackTrace();
	 		}
	 	}
		public void updateBloodBankCenter(int id,String name) {
			logger.info("In controller for updation......");
			try {
				bloodBankServiceImpl.updateBloodBankCenter(id,name);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		public List<BloodBankCenter> getAllcenters() {
				logger.info("In controller for displaying all lists.....");
				return bloodBankServiceImpl.getAllcenters();
		}
		public List<BloodBankCenter> getCenterById(int id) {
				logger.info("In controller for displaying details of specific id.......");
				return bloodBankServiceImpl.getCenterById(id);
			
		}

}
